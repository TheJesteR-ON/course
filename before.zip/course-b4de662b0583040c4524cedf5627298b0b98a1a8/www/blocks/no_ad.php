<div class = "no-ad-block">
    <!-- <img width = "400px" src="../Images/no_ad.png" alt="NO"> -->
    <i class="far fa-frown-open"></i>
    <p class = "no-ad-text">Результатов не найдено</p>
</div>